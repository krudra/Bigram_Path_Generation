'''
Created on Sep 26, 2016

@author: krudra
'''
import WGGraph as wg
import os
import re, sys
import kenlm, codecs
from sentenceRanker import createDict

BASEPATH = '../../Path_Generation/'

def remove_unwanted_elements(tweets):
    sents=[]
    remove_list=['/#', '/@', '/~', '/U', '/E', '/G']
    for tweet in tweets:
        words = []
        for word in tweet.split(" "):
            if word[-2:] not in remove_list and word[:2] not in ":/":
                words.append(word)
        sents.append(' '.join(m.lstrip("#") for m in words))
    return sents 

def find_bigrams(input_list):
    bigram_list=[]
    for i in range(len(input_list)-1):
        bigram_list.append((input_list[i], input_list[i+1]))
    return bigram_list

def bigramTweetGenerator(tweets):
    bigramTweets=[]
    for tweet in tweets:
        bitweet=''
        tweet=tweet.strip().lower()
        #print 'Tweet:', tweet
        words=tweet.split(" ")
        bigramlist=find_bigrams(words)
        for bigrams in bigramlist:
            bigramword=''
            #print bigrams
            word1, word2=bigrams
            m1 = re.match("^(.+)/(.+)$", word1)
            m2 = re.match("^(.+)/(.+)$", word2)
            if m1 and m2:
                bigramword=m1.group(1)+"||"+m2.group(1)+"/"+m1.group(2)+"||"+m2.group(2)
                bitweet=bitweet+" "+bigramword
        if len(bitweet.strip())>0:
            bigramTweets.append(bitweet.strip())
    #print "Bigram tweets", bigramTweets
    return bigramTweets
    #print 'Bigram list', bigramlist


def generateWordGraphPathsNew(file_name, lm):
    
    f_r=codecs.open(BASEPATH+file_name,"r")           
    f_path_details=codecs.open(BASEPATH\
                               +file_name+'_details.txt',\
                               'w', errors='ignore')
    writepathsfile=codecs.open(BASEPATH+file_name+"_paths","w", errors="ignore")
    tweets=[]
    for line in f_r:
        tweet=line.strip()
        tweets.append(tweet)
                    
    total_tweets=len(tweets)
    print("Total tweets ==> {}".format(total_tweets))
    tweets=remove_unwanted_elements(tweets)
    tweets=list(set(tweets))
    tweets=bigramTweetGenerator(tweets)
    print("Total tweets removed duplicates==> {}".format(len(tweets)))
    wordScores=None
    stopwords=wg.load_stopwords(BASEPATH+"stopwords.en.dat")
    wg.create_new_paths(tweets, stopwords, writepathsfile, lm, f_path_details, wordScores)
    
if __name__ == '__main__':
    lm = kenlm.Model('lm/test.arpa')
    generateWordGraphPathsNew(sys.argv[1], lm) #, ranker = 'textrank')
