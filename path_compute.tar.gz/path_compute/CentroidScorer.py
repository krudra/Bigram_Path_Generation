'''
Created on Sep 26, 2016

@author: siddban
'''
from sklearn.feature_extraction.text import TfidfVectorizer
from nltk.corpus import stopwords
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity


def tokenize(s):
    return s.split()

def centroidScores(docs):
    stopwords_list = stopwords.words('english')
    tfidf_vectorizer = TfidfVectorizer(tokenizer = tokenize, min_df=2, stop_words=stopwords_list)
    tfidf_matrix_train = tfidf_vectorizer.fit_transform(docs)  #finds the tfidf score with normalization
    
    print(type(tfidf_matrix_train))
    tfidf_matrix_train  = tfidf_matrix_train.toarray()
    centroid = np.mean(tfidf_matrix_train, axis = 0)
    
    centroid_scores = []
    for x in tfidf_matrix_train:
        cosineSimilarities=cosine_similarity(x.reshape(1,-1), centroid.reshape(1,-1))
        centroid_scores.append(cosineSimilarities[0][0]) 
    return centroid_scores
    
if __name__ == '__main__':
    documents = ["Human machine interface for lab abc computer applications",
            "A survey of user opinion of computer system response time",
            "The EPS user interface management system",
            "System and human system engineering testing of EPS",
            "Relation of user perceived response time to error measurement",
            "The generation of random binary unordered trees",
            "The intersection graph of paths in trees",
            "Graph minors IV Widths of trees and well quasi ordering",
            "Graph minors A survey"]
    a = np.array([[1,2,3], [3,4,6]])
    #print a.shape, b.shape
    print(np.mean(a, axis = 0))
    print(centroidScores(documents))
